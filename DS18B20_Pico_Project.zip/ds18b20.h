
#ifndef DS18B20_H
#define DS18B20_H

#include "pico/stdlib.h"

class DS18B20 {
public:
    DS18B20(uint gpio);
    bool begin();
    float readTemperature();

private:
    uint data_pin;
    void writeBit(bool bit);
    bool readBit();
    void writeByte(uint8_t byte);
    uint8_t readByte();
    void resetPulse();
};

#endif
