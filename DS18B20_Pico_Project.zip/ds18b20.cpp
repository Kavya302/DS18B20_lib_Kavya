
#include "ds18b20.h"
#include "hardware/gpio.h"
#include "pico/stdlib.h"

DS18B20::DS18B20(uint gpio) : data_pin(gpio) {
    gpio_init(data_pin);
    gpio_set_dir(data_pin, GPIO_OUT);
    gpio_put(data_pin, 1);
}

bool DS18B20::begin() {
    resetPulse();
    writeByte(0xCC);  // Skip ROM
    writeByte(0x44);  // Convert T
    sleep_ms(750);    // Wait for conversion
    resetPulse();
    writeByte(0xCC);  // Skip ROM
    writeByte(0xBE);  // Read Scratchpad
    return true;
}

float DS18B20::readTemperature() {
    resetPulse();
    writeByte(0xCC);
    writeByte(0xBE);

    uint8_t lsb = readByte();
    uint8_t msb = readByte();

    int16_t raw = (msb << 8) | lsb;
    return raw / 16.0;
}

void DS18B20::resetPulse() {
    gpio_set_dir(data_pin, GPIO_OUT);
    gpio_put(data_pin, 0);
    sleep_us(480);
    gpio_set_dir(data_pin, GPIO_IN);
    sleep_us(480);
}

void DS18B20::writeBit(bool bit) {
    gpio_set_dir(data_pin, GPIO_OUT);
    gpio_put(data_pin, 0);
    sleep_us(bit ? 1 : 60);
    gpio_put(data_pin, 1);
    sleep_us(bit ? 60 : 1);
}

bool DS18B20::readBit() {
    gpio_set_dir(data_pin, GPIO_OUT);
    gpio_put(data_pin, 0);
    sleep_us(1);
    gpio_set_dir(data_pin, GPIO_IN);
    sleep_us(14);
    return gpio_get(data_pin);
}

void DS18B20::writeByte(uint8_t byte) {
    for (int i = 0; i < 8; ++i) {
        writeBit(byte & 1);
        byte >>= 1;
    }
}

uint8_t DS18B20::readByte() {
    uint8_t byte = 0;
    for (int i = 0; i < 8; ++i) {
        if (readBit()) byte |= (1 << i);
        sleep_us(60);
    }
    return byte;
}
