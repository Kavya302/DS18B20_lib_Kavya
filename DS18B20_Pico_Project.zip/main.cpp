
#include <stdio.h>
#include "pico/stdlib.h"
#include "ds18b20.h"

#define DS18B20_PIN 2

int main() {
    stdio_init_all();
    DS18B20 sensor(DS18B20_PIN);

    while (true) {
        if (sensor.begin()) {
            float temp = sensor.readTemperature();
            printf("Temperature: %.2f °C\n", temp);
        } else {
            printf("Sensor not detected.\n");
        }
        sleep_ms(1000);
    }
}
